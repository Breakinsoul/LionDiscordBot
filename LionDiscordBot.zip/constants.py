
class constants:
    GUILD_ID = 188669988012294144
    MAIN_CHANNEL_ID = 188669988012294144
    RU_NEWS_CHANNEL_ID = 1129727780528078918
    RULES_CNANNEL_ID = 945713995606814801
    USER_ROLE_ID = 463128518562152461
    MEMBERSHIP_REQ_CHANNEL_ID = 945664078305693736
    OF_ROLE_ID = 197084204297617408
    CANDIDATE_ROLE_ID = 1139581517299990658
    giveaway_league = 'Ancestor'
    autocomplete_settings_league = ['Standard', 'Ancestor', 'Hardcore', 'AncestorHC']
    any_api_entry = 'https://www.poewiki.net/api.php?action=cargoquery&tables=items&fields=name,class,drop_areas_html,rarity,tags&group_by=name&format=json&where=NOT class="Quest Item" AND NOT class="Cosmetic Item" AND NOT class="Hideout Decoration" AND name LIKE "%'
    uniq_api_entry ='https://www.poewiki.net/api.php?action=cargoquery&tables=items&fields=name,class,drop_areas_html,rarity,tags&group_by=name&format=json&where=rarity="Unique" AND NOT class="Quest Item" AND NOT class="Cosmetic Item" AND NOT class="Hideout Decoration" AND name LIKE "%'

    json_reg_file = 'registration_data.json'
    default_league = 'Standard'
    default_visibility = 'Public'
